# Study Notes (MAD Lab – Q1)

Android app that saves daily study notes as a text file on external storage and reads them back.

## Features
- Checks whether external storage (SD card / shared storage) is mounted and writable
- Asks for storage permission at runtime (needed on Android 6–9; not required on Android 10+ for the app's own folder)
- **Save Note** – appends the note (with date/time) to `study_notes.txt`
- **Read Saved Notes** – reads the file and shows it on screen
- File location: `Android/data/com.example.studynotes/files/study_notes.txt`

## Run in Android Studio
1. `File > Open` and select this folder
2. Wait for Gradle sync
3. Start an emulator / connect a phone, press **Run**

## Run with the .bat file (Windows)
1. Start an emulator or connect a phone with USB debugging
2. Double-click `run_app.bat`

Requires JDK 17 (bundled with Android Studio) and Android SDK 34.
