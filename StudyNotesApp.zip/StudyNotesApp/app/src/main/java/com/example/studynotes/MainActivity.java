package com.example.studynotes;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_STORAGE = 101;
    private static final String FILE_NAME = "study_notes.txt";

    private static final int ACTION_NONE = 0;
    private static final int ACTION_SAVE = 1;
    private static final int ACTION_READ = 2;

    private EditText etNote;
    private TextView tvContent, tvStatus;
    private int pendingAction = ACTION_NONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNote = findViewById(R.id.etNote);
        tvContent = findViewById(R.id.tvContent);
        tvStatus = findViewById(R.id.tvStatus);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnRead = findViewById(R.id.btnRead);

        updateStatus();

        btnSave.setOnClickListener(v -> {
            pendingAction = ACTION_SAVE;
            runWithPermission();
        });

        btnRead.setOnClickListener(v -> {
            pendingAction = ACTION_READ;
            runWithPermission();
        });
    }

    // ---------- Storage availability ----------

    private boolean isStorageWritable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    private boolean isStorageReadable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state)
                || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }

    private void updateStatus() {
        if (isStorageWritable()) {
            File f = getNotesFile();
            tvStatus.setText("Storage: available\nFile: " + (f != null ? f.getAbsolutePath() : "n/a"));
        } else if (isStorageReadable()) {
            tvStatus.setText("Storage: READ-ONLY (cannot save)");
        } else {
            tvStatus.setText("Storage: NOT available");
        }
    }

    /** File inside the app's folder on external storage (Android/data/<package>/files). */
    private File getNotesFile() {
        File dir = getExternalFilesDir(null);
        return dir == null ? null : new File(dir, FILE_NAME);
    }

    // ---------- Permissions ----------

    /** Runtime permission is only required on Android 6 – 9 (API 23–28). */
    private boolean needsRuntimePermission() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P;
    }

    private boolean hasStoragePermission() {
        if (!needsRuntimePermission()) return true;
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void runWithPermission() {
        if (hasStoragePermission()) {
            performPendingAction();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_STORAGE) return;

        boolean granted = grantResults.length > 0;
        for (int r : grantResults) {
            if (r != PackageManager.PERMISSION_GRANTED) granted = false;
        }
        if (granted) {
            performPendingAction();
        } else {
            Toast.makeText(this, "Storage permission denied", Toast.LENGTH_LONG).show();
            pendingAction = ACTION_NONE;
        }
    }

    private void performPendingAction() {
        if (pendingAction == ACTION_SAVE) saveNote();
        else if (pendingAction == ACTION_READ) readNotes();
        pendingAction = ACTION_NONE;
    }

    // ---------- Save / Read ----------

    private void saveNote() {
        String text = etNote.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "Please type a note first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!isStorageWritable()) {
            Toast.makeText(this, "External storage not available for writing", Toast.LENGTH_LONG).show();
            updateStatus();
            return;
        }
        File file = getNotesFile();
        if (file == null) {
            Toast.makeText(this, "Could not access storage folder", Toast.LENGTH_LONG).show();
            return;
        }

        String stamp = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(new Date());
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8")) {
            w.write("[" + stamp + "]\n" + text + "\n\n");
            etNote.setText("");
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
            updateStatus();
        } catch (IOException e) {
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void readNotes() {
        if (!isStorageReadable()) {
            Toast.makeText(this, "External storage not available", Toast.LENGTH_LONG).show();
            updateStatus();
            return;
        }
        File file = getNotesFile();
        if (file == null || !file.exists()) {
            tvContent.setText("No saved notes yet.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            tvContent.setText(sb.length() == 0 ? "File is empty." : sb.toString());
        } catch (IOException e) {
            Toast.makeText(this, "Read failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
