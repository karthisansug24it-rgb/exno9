@echo off
setlocal
cd /d "%~dp0"
title Study Notes - Build and Run

rem ---- locate Android SDK ----
set "SDK=%ANDROID_HOME%"
if "%SDK%"=="" set "SDK=%ANDROID_SDK_ROOT%"
if "%SDK%"=="" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not exist "%SDK%\platform-tools\adb.exe" goto nosdk

rem ---- write local.properties if missing ----
set "SDKF=%SDK:\=/%"
if not exist local.properties echo sdk.dir=%SDKF%> local.properties

rem ---- check that a device / emulator is connected ----
"%SDK%\platform-tools\adb.exe" start-server >nul 2>&1
"%SDK%\platform-tools\adb.exe" devices | findstr /R /C:"	device$" >nul
if errorlevel 1 goto nodevice

if not exist gradlew.bat goto nowrapper

echo Building and installing the app...
call gradlew.bat installDebug
if errorlevel 1 goto fail

echo Launching...
"%SDK%\platform-tools\adb.exe" shell am start -n com.example.studynotes/.MainActivity
goto end

:nosdk
echo [ERROR] Android SDK not found. Set ANDROID_HOME or install Android Studio.
goto end

:nodevice
echo [ERROR] No emulator/phone detected. Start an emulator from Android Studio
echo         (Device Manager) or connect a phone with USB debugging, then run again.
goto end

:nowrapper
echo [ERROR] gradlew.bat not found. Open this folder in Android Studio once
echo         (it will set up Gradle), or press the green Run button instead.
goto end

:fail
echo [ERROR] Build failed. Open the project in Android Studio to see the details.

:end
pause
